# 🛍️ Telegram Bot Shop — Atlantic H2H Edition

Bot toko digital Telegram dengan payment gateway **Atlantic H2H** (atlantich2h.com), panel admin web modern, manajemen stok fleksibel, dan fitur broadcast.

---

## ✨ Fitur Utama

### Bot Telegram
- 🛍️ **Toko Digital** – Browse produk, tambah ke keranjang, checkout
- 💳 **Top Up Saldo** – Via Atlantic H2H (QRIS, VA BCA/BNI/BRI/Mandiri, GoPay, OVO, DANA, ShopeePay)
- 🔄 **Cek Status Pembayaran** – Real-time via tombol inline
- 🎟️ **Voucher/Redeem Code** – Tukar kode untuk saldo
- 📋 **Riwayat Pesanan & Transaksi**
- 📢 **Admin: Broadcast** ke semua/sebagian pelanggan
- 📊 **Admin: Statistik** via `/stats`
- 🔑 **Produk Digital** – kode, link download, file

### Panel Admin Web (`/admin`)
- 📊 **Dashboard** – statistik real-time
- 📦 **Manajemen Produk** – CRUD produk, edit harga, aktifkan/nonaktifkan
- 📦 **Manajemen Stok Fleksibel:**
  - ✍️ Input manual (satu per baris)
  - 📋 Bulk paste (baris/koma/titik koma)
  - ⚡ Auto-generate kode
  - 🗑️ Hapus kode terpakai
- 💳 **Monitor Pembayaran** – cek status, filter, refresh
- 👥 **Manajemen Pengguna** – lihat saldo, top up manual
- 🎟️ **Voucher** – buat, bulk generate, hapus
- 📢 **Broadcast Web** – kirim pesan ke semua/pengguna aktif langsung dari browser
- ⚙️ **Pengaturan** – konfigurasi bot message, metode pembayaran default

---

## 🚀 Cara Install

### 1. Clone & Install
```bash
git clone <repo>
cd telegramshopbot
npm install
```

### 2. Konfigurasi
```bash
cp env.example .env
nano .env   # atau gunakan editor favorit Anda
```

Isi nilai berikut di `.env`:
| Variable | Keterangan |
|---|---|
| `TELEGRAM_BOT_TOKEN` | Token dari @BotFather |
| `ATLANTIC_MERCHANT_ID` | Merchant ID dari atlantich2h.com |
| `ATLANTIC_SECRET_KEY` | Secret key Atlantic H2H |
| `ATLANTIC_API_KEY` | API key Atlantic H2H |
| `BASE_URL` | URL publik server Anda |
| `ADMIN_USERNAME` | Username login panel admin |
| `ADMIN_PASSWORD` | Password login panel admin |
| `JWT_SECRET` | String acak panjang untuk keamanan |

### 3. Setup Database & Data Contoh (opsional)
```bash
npm run sample-data
```

### 4. Jalankan
```bash
# Production
npm start

# Development (auto-restart)
npm run dev
```

### 5. Akses Panel Admin
Buka browser: `http://localhost:3000/admin`

---

## 💳 Konfigurasi Atlantic H2H

1. Daftar di [atlantich2h.com](https://atlantich2h.com)
2. Dapatkan Merchant ID, Secret Key, dan API Key dari dashboard
3. Isi di file `.env`
4. Set `BASE_URL` ke domain publik Anda (untuk callback webhook)
5. Daftarkan callback URL di dashboard Atlantic: `https://yourdomain.com/api/payment/callback`

### Metode Pembayaran Tersedia
| Kode | Nama |
|---|---|
| `QRIS` | QRIS (default) |
| `VA_BCA` | Virtual Account BCA |
| `VA_BNI` | Virtual Account BNI |
| `VA_BRI` | Virtual Account BRI |
| `VA_MANDIRI` | Virtual Account Mandiri |
| `GOPAY` | GoPay |
| `OVO` | OVO |
| `DANA` | DANA |
| `SHOPEEPAY` | ShopeePay |

---

## 📱 Perintah Bot

### User
| Perintah | Fungsi |
|---|---|
| `/start` | Menu utama |
| `/shop` | Lihat produk |
| `/cart` | Keranjang belanja |
| `/balance` | Cek saldo |
| `/deposit` | Top up saldo |
| `/orders` | Riwayat pesanan |
| `/redeem` | Tukar kode voucher |
| `/status REF` | Cek status pembayaran |

### Admin
| Perintah | Fungsi |
|---|---|
| `/admin` | Panel admin Telegram |
| `/broadcast` | Broadcast ke semua user |
| `/stats` | Statistik toko |

---

## 🏗️ Struktur Folder

```
src/
├── api/adminAPI.js          # REST API admin panel
├── bot/botHandler.js        # Logic bot Telegram
├── config/tripay.js         # (legacy, tidak digunakan)
├── database/database.js     # SQLite database
├── routes/paymentRoutes.js  # Webhook Atlantic H2H
├── services/
│   ├── atlanticService.js   # Atlantic H2H API client
│   ├── paymentService.js    # Payment business logic
│   └── paymentScheduler.js  # Auto-poll pending payments
└── index.js                 # Entry point

public/
├── index.html               # Admin dashboard (single-page)
└── login.html               # Halaman login admin
```

---

## 🔒 Keamanan

- Autentikasi JWT untuk admin panel
- Signature verification untuk callback Atlantic H2H
- Ganti `ADMIN_PASSWORD` dan `JWT_SECRET` di `.env`
- Gunakan HTTPS di production
- Jangan commit file `.env` ke repository

---

## 📝 License
MIT
