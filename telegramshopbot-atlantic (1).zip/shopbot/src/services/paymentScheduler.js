class PaymentScheduler {
    constructor(paymentService) {
        this.paymentService = paymentService;
        this.pollingInterval = null;
        this.isRunning = false;
        this.intervalMinutes = 5;
        this.lastRun = null;
    }

    startPolling(intervalMinutes = 5) {
        if (this.isRunning) this.stopPolling();
        this.intervalMinutes = intervalMinutes;
        this.isRunning = true;
        this.pollingInterval = setInterval(() => this.pollAllPending(), intervalMinutes * 60 * 1000);
        console.log(`[PaymentScheduler] Started every ${intervalMinutes} min`);
    }

    stopPolling() {
        if (this.pollingInterval) clearInterval(this.pollingInterval);
        this.pollingInterval = null;
        this.isRunning = false;
    }

    async pollAllPending() {
        this.lastRun = new Date().toISOString();
        try {
            const db = this.paymentService.db;
            const pending = await db.all(`SELECT * FROM balance_payments WHERE status='PENDING' AND created_at > datetime('now','-24 hours')`);
            console.log(`[PaymentScheduler] Checking ${pending.length} pending`);
            for (const p of pending) {
                try { await this.paymentService.checkPaymentStatus(p.tripay_reference); }
                catch(e) { console.error(`[Scheduler] ${p.tripay_reference}: ${e.message}`); }
            }
        } catch(e) { console.error('[Scheduler] Poll error:', e); }
    }

    async pollPayment(reference) { return this.paymentService.checkPaymentStatus(reference); }

    getStatus() { return { isRunning: this.isRunning, intervalMinutes: this.intervalMinutes, lastRun: this.lastRun }; }
}

module.exports = PaymentScheduler;
