/**
 * Atlantic H2H Payment Gateway Service
 * Integrates with atlantich2h.com for payment processing
 */
const axios = require('axios');
const crypto = require('crypto');

const atlanticConfig = {
    baseUrl: process.env.ATLANTIC_BASE_URL || 'https://atlantich2h.com/api/v1',
    merchantId: process.env.ATLANTIC_MERCHANT_ID || '',
    secretKey: process.env.ATLANTIC_SECRET_KEY || '',
    apiKey: process.env.ATLANTIC_API_KEY || '',
};

const generateSignature = (payload, secretKey) => {
    const sorted = Object.keys(payload).sort().reduce((obj, key) => {
        obj[key] = payload[key];
        return obj;
    }, {});
    const str = Object.entries(sorted).map(([k, v]) => `${k}=${v}`).join('&');
    return crypto.createHmac('sha256', secretKey).update(str).digest('hex');
};

const generateMerchantRef = (prefix = 'DEP') => {
    return `${prefix}${Date.now()}${Math.random().toString(36).substring(2,7).toUpperCase()}`;
};

const getClient = () => axios.create({
    baseURL: atlanticConfig.baseUrl,
    timeout: 30000,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        ...(atlanticConfig.apiKey && { 'Authorization': `Bearer ${atlanticConfig.apiKey}` }),
    }
});

const createDeposit = async ({ amount, merchantRef, customerName, customerEmail, customerPhone, paymentMethod = 'QRIS', description = 'Top Up Saldo' }) => {
    try {
        const payload = {
            merchant_id: atlanticConfig.merchantId,
            merchant_ref: merchantRef,
            amount: Math.round(amount),
            customer_name: customerName,
            customer_email: customerEmail || `user@shop.id`,
            customer_phone: customerPhone || '08123456789',
            payment_method: paymentMethod,
            description,
            callback_url: process.env.BASE_URL ? `${process.env.BASE_URL}/api/payment/callback` : '',
            return_url: `${process.env.BASE_URL || 'http://localhost:3000'}/payment/success`,
        };
        payload.signature = generateSignature(payload, atlanticConfig.secretKey);

        const res = await getClient().post('/deposit/create', payload);
        if (res.data?.success) {
            return {
                success: true,
                data: {
                    reference: res.data.data?.reference || res.data.data?.transaction_id || merchantRef,
                    merchantRef,
                    paymentUrl: res.data.data?.payment_url,
                    qrUrl: res.data.data?.qr_url,
                    qrString: res.data.data?.qr_string,
                    vaNumber: res.data.data?.va_number,
                    bankName: res.data.data?.bank_name,
                    amount,
                    expiredAt: res.data.data?.expired_at,
                    status: 'PENDING',
                    paymentMethod,
                    raw: res.data.data,
                }
            };
        }
        throw new Error(res.data?.message || 'Failed to create transaction');
    } catch (error) {
        if (error.response) throw new Error(`Atlantic H2H: ${error.response.data?.message || error.response.statusText}`);
        throw error;
    }
};

const checkTransactionStatus = async (reference) => {
    try {
        const payload = { merchant_id: atlanticConfig.merchantId, reference };
        payload.signature = generateSignature(payload, atlanticConfig.secretKey);
        const res = await getClient().post('/deposit/status', payload);
        return {
            success: true,
            data: {
                reference,
                status: res.data?.data?.status || res.data?.status || 'PENDING',
                amount: res.data?.data?.amount,
                paidAt: res.data?.data?.paid_at,
                raw: res.data,
            }
        };
    } catch (error) {
        if (error.response) throw new Error(`Status Check Error: ${error.response.data?.message || error.response.statusText}`);
        throw error;
    }
};

const getPaymentChannels = async () => {
    // Default channels - override if API supports it
    return [
        { code: 'QRIS', name: 'QRIS (Semua E-Wallet)', type: 'qris', icon: '📱', fee: 0.7 },
        { code: 'VA_BCA', name: 'Virtual Account BCA', type: 'va', icon: '🏦', fee: 4000 },
        { code: 'VA_BNI', name: 'Virtual Account BNI', type: 'va', icon: '🏦', fee: 4000 },
        { code: 'VA_BRI', name: 'Virtual Account BRI', type: 'va', icon: '🏦', fee: 4000 },
        { code: 'VA_MANDIRI', name: 'Virtual Account Mandiri', type: 'va', icon: '🏦', fee: 4000 },
        { code: 'GOPAY', name: 'GoPay', type: 'ewallet', icon: '💚', fee: 0 },
        { code: 'OVO', name: 'OVO', type: 'ewallet', icon: '💜', fee: 0 },
        { code: 'DANA', name: 'DANA', type: 'ewallet', icon: '💙', fee: 0 },
        { code: 'SHOPEEPAY', name: 'ShopeePay', type: 'ewallet', icon: '🧡', fee: 0 },
    ];
};

const verifyCallback = (payload, receivedSig) => {
    const { signature, ...rest } = payload;
    return generateSignature(rest, atlanticConfig.secretKey) === receivedSig;
};

module.exports = { atlanticConfig, generateMerchantRef, createDeposit, checkTransactionStatus, getPaymentChannels, verifyCallback };
