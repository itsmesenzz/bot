/**
 * Payment Service - Atlantic H2H Integration
 */
const { createDeposit, checkTransactionStatus, generateMerchantRef, getPaymentChannels } = require('./atlanticService');

class PaymentService {
    constructor(db) { this.db = db; }

    async createBalancePayment(userId, amount, customerName, customerPhone = null, customerEmail = null, paymentMethod = null) {
        const merchantRef = generateMerchantRef('BAL');
        const paymentConfig = await this.db.getPaymentMethodConfig().catch(() => null);
        const method = paymentMethod || (paymentConfig?.default_method) || 'QRIS';

        const result = await createDeposit({
            amount: Math.round(amount), merchantRef,
            customerName, customerEmail: customerEmail || `user${userId}@shop.id`,
            customerPhone: customerPhone || '08123456789',
            paymentMethod: method, description: `Top Up Saldo - ${customerName}`,
        });

        await this.db.run(`
            INSERT INTO balance_payments (user_id,merchant_ref,tripay_reference,amount,status,payment_url,created_at)
            VALUES (?,?,?,?,?,?,datetime('now'))
        `, [userId, merchantRef, result.data.reference, amount, 'PENDING', result.data.paymentUrl || result.data.qrUrl || '-']);

        return { success: true, data: { ...result.data, amount } };
    }

    async checkPaymentStatus(reference) {
        const result = await checkTransactionStatus(reference);
        const status = (result.data.status || '').toUpperCase();
        const isPaid = ['PAID','SUCCESS','SETTLEMENT','COMPLETE'].includes(status);
        if (isPaid) {
            const payment = await this.db.get('SELECT * FROM balance_payments WHERE tripay_reference=?', [reference]);
            if (payment && payment.status !== 'PAID') {
                await this.db.run(`UPDATE balance_payments SET status='PAID',updated_at=datetime('now') WHERE tripay_reference=?`, [reference]);
                await this.db.depositToBalance(payment.user_id, payment.amount, `Top Up Atlantic H2H - ${reference}`);
                return { ...result, credited: true, payment };
            }
        }
        return result;
    }

    // Alias used in botHandler
    async pollPaymentStatus(reference) { return this.checkPaymentStatus(reference); }

    async processCallback(data) {
        const reference = data.reference || data.transaction_id;
        const status = (data.status || '').toUpperCase();
        const isPaid = ['PAID','SUCCESS','SETTLEMENT'].includes(status);
        const payment = await this.db.get('SELECT * FROM balance_payments WHERE tripay_reference=?', [reference]);
        if (!payment) return null;
        if (isPaid && payment.status !== 'PAID') {
            await this.db.run(`UPDATE balance_payments SET status='PAID',updated_at=datetime('now') WHERE tripay_reference=?`, [reference]);
            await this.db.depositToBalance(payment.user_id, payment.amount, `Top Up Atlantic H2H - ${reference}`);
            return { ...payment, justPaid: true };
        }
        return payment;
    }

    async getUserPaymentHistory(userId, limit = 10) {
        return this.db.all(`SELECT * FROM balance_payments WHERE user_id=? ORDER BY created_at DESC LIMIT ?`, [userId, limit]);
    }

    async getAllPayments(limit = 50) {
        return this.db.all(`
            SELECT bp.*, u.username, u.first_name, u.telegram_id
            FROM balance_payments bp LEFT JOIN users u ON bp.user_id=u.id
            ORDER BY bp.created_at DESC LIMIT ?`, [limit]);
    }

    async getChannels() { return getPaymentChannels(); }
}

module.exports = PaymentService;
