const express = require('express');
const router = express.Router();
const { verifyCallback } = require('../services/atlanticService');

let botInstance = null;
let paymentServiceInstance = null;

const setBotInstance = (bot, paymentService) => {
    botInstance = bot;
    paymentServiceInstance = paymentService;
};

// Atlantic H2H Callback/Webhook
router.post('/payment/callback', async (req, res) => {
    try {
        const data = req.body;
        console.log('[Callback] Received:', JSON.stringify(data));

        // Optionally verify signature
        if (data.signature && paymentServiceInstance) {
            const valid = verifyCallback(data, data.signature);
            if (!valid) {
                console.warn('[Callback] Invalid signature');
                return res.status(400).json({ success: false, message: 'Invalid signature' });
            }
        }

        if (paymentServiceInstance) {
            const result = await paymentServiceInstance.processCallback(data);
            if (result?.justPaid && botInstance) {
                // Notify user via Telegram
                const db = paymentServiceInstance.db;
                const user = await db.get('SELECT * FROM users WHERE id=?', [result.user_id]);
                if (user?.telegram_id) {
                    const newBal = await db.getUserBalance(result.user_id);
                    await botInstance.sendMessage(user.telegram_id,
                        `🎉 *Pembayaran Diterima!*\n\n💰 Jumlah: Rp${result.amount.toLocaleString('id-ID')}\n💳 Saldo Baru: Rp${newBal.toLocaleString('id-ID')}\n🔢 Ref: \`${result.tripay_reference}\`\n\nSaldo Anda telah diperbarui! Gunakan /shop untuk berbelanja.`,
                        { parse_mode: 'Markdown' }
                    );
                }
            }
        }

        res.json({ success: true, message: 'OK' });
    } catch (err) {
        console.error('[Callback] Error:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

// Manual check
router.get('/payment/status/:reference', async (req, res) => {
    try {
        if (!paymentServiceInstance) return res.status(503).json({ success: false, message: 'Service not ready' });
        const result = await paymentServiceInstance.checkPaymentStatus(req.params.reference);
        res.json({ success: true, data: result });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// Success redirect
router.get('/payment/success', (req, res) => {
    res.redirect('/admin#payments');
});

module.exports = { router, setBotInstance };
