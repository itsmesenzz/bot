const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { getPaymentChannels } = require('../services/atlanticService');

class AdminAPI {
    constructor(db, bot = null) {
        this.db = db;
        this.bot = bot;
        this.router = express.Router();
        this.setupFileUpload();
        this.setupRoutes();
    }

    setBot(bot) { this.bot = bot; }

    setupFileUpload() {
        const uploadPath = process.env.UPLOAD_PATH || './uploads';
        fs.ensureDirSync(uploadPath);
        const storage = multer.diskStorage({
            destination: (req, file, cb) => cb(null, uploadPath),
            filename: (req, file, cb) => cb(null, `${uuidv4()}-${file.originalname}`),
        });
        this.upload = multer({ storage, limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE)||10*1024*1024 } });
    }

    auth(req, res, next) {
        const token = req.headers.authorization?.split(' ')[1] || req.headers['x-admin-token'];
        if (!token) return res.status(401).json({ success: false, error: 'Unauthorized' });
        try {
            req.admin = jwt.verify(token, process.env.JWT_SECRET || 'secret');
            next();
        } catch { return res.status(401).json({ success: false, error: 'Invalid token' }); }
    }

    authenticateAdmin(req, res, next) { return this.auth(req, res, next); }

    setupRoutes() {
        // Login (public)
        this.router.post('/login', this.login.bind(this));

        // Protected routes
        this.router.use(this.auth.bind(this));

        // Dashboard stats
        this.router.get('/stats', this.getStats.bind(this));

        // Products
        this.router.get('/products', this.getProducts.bind(this));
        this.router.get('/products/:id', this.getProduct.bind(this));
        this.router.post('/products', this.upload.single('file'), this.createProduct.bind(this));
        this.router.put('/products/:id', this.upload.single('file'), this.updateProduct.bind(this));
        this.router.delete('/products/:id', this.deleteProduct.bind(this));

        // Stock / Product Codes – flexible management
        this.router.get('/products/:id/codes', this.getProductCodes.bind(this));
        this.router.post('/products/:id/codes', this.addProductCodes.bind(this));           // add codes (array or single)
        this.router.post('/products/:id/codes/bulk', this.bulkAddCodes.bind(this));         // paste bulk text
        this.router.post('/products/:id/codes/generate', this.generateProductCodes.bind(this)); // auto-generate
        this.router.delete('/products/:id/codes/used', this.deleteUsedCodes.bind(this));    // clear used codes
        this.router.delete('/codes/:codeId', this.deleteProductCode.bind(this));

        // Categories
        this.router.get('/categories', this.getCategories.bind(this));
        this.router.post('/categories', this.createCategory.bind(this));
        this.router.put('/categories/:id', this.updateCategory.bind(this));
        this.router.delete('/categories/:id', this.deleteCategory.bind(this));

        // Orders
        this.router.get('/orders', this.getOrders.bind(this));
        this.router.get('/orders/:id', this.getOrder.bind(this));
        this.router.put('/orders/:id/status', this.updateOrderStatus.bind(this));

        // Users
        this.router.get('/users', this.getUsers.bind(this));
        this.router.get('/users/:id', this.getUser.bind(this));
        this.router.post('/users/:id/balance/deposit', this.depositUserBalance.bind(this));
        this.router.post('/users/:id/balance/withdraw', this.withdrawUserBalance.bind(this));

        // Payments / Deposits
        this.router.get('/payments', this.getAllPayments.bind(this));
        this.router.get('/payments/:reference/status', this.checkPaymentStatus.bind(this));

        // Transactions
        this.router.get('/transactions', this.getAllTransactions.bind(this));

        // Redeem Codes
        this.router.get('/redeem-codes', this.getAllRedeemCodes.bind(this));
        this.router.post('/redeem-codes', this.createRedeemCode.bind(this));
        this.router.post('/redeem-codes/generate', this.generateRedeemCode.bind(this));
        this.router.post('/redeem-codes/bulk', this.bulkGenerateRedeemCodes.bind(this));
        this.router.delete('/redeem-codes/:id', this.deleteRedeemCode.bind(this));

        // Payment Channels
        this.router.get('/payment-channels', this.getPaymentChannels.bind(this));
        this.router.get('/payment-method-config', this.getPaymentMethodConfig.bind(this));
        this.router.post('/payment-method-config', this.updatePaymentMethodConfig.bind(this));

        // Atlantic H2H Config
        this.router.get('/atlantic-config', this.getAtlanticConfig.bind(this));
        this.router.post('/atlantic-config', this.updateAtlanticConfig.bind(this));

        // Bot Config
        this.router.get('/bot-config', this.getBotConfig.bind(this));
        this.router.post('/bot-config', this.updateBotConfig.bind(this));

        // Broadcast (web-triggered)
        this.router.post('/broadcast', this.sendBroadcast.bind(this));

        // Analytics
        this.router.get('/analytics', this.getAnalytics.bind(this));

        // Files
        this.router.get('/files', this.getFiles.bind(this));
        this.router.delete('/files/:filename', this.deleteFile.bind(this));
    }

    // ── Auth ─────────────────────────────────────────
    async login(req, res) {
        const { username, password } = req.body;
        const adminUser = process.env.ADMIN_USERNAME || 'admin';
        const adminPass = process.env.ADMIN_PASSWORD || 'admin123';
        if (username !== adminUser || password !== adminPass)
            return res.status(401).json({ success: false, error: 'Invalid credentials' });
        const token = jwt.sign({ username }, process.env.JWT_SECRET || 'secret', { expiresIn: '24h' });
        res.json({ success: true, token });
    }

    // ── Stats ─────────────────────────────────────────
    async getStats(req, res) {
        try {
            const [products, orders, users, revenue, pendingOrders, totalDeposit, todayOrders, todayDeposit] = await Promise.all([
                this.db.get('SELECT COUNT(*) as c FROM products WHERE is_active=1'),
                this.db.get('SELECT COUNT(*) as c FROM orders'),
                this.db.get('SELECT COUNT(*) as c FROM users WHERE is_admin=0'),
                this.db.get(`SELECT COALESCE(SUM(total_price),0) as t FROM orders WHERE status='completed'`),
                this.db.get(`SELECT COUNT(*) as c FROM orders WHERE status='pending'`),
                this.db.get(`SELECT COALESCE(SUM(amount),0) as t FROM balance_payments WHERE status='PAID'`),
                this.db.get(`SELECT COUNT(*) as c FROM orders WHERE date(created_at)=date('now')`),
                this.db.get(`SELECT COALESCE(SUM(amount),0) as t FROM balance_payments WHERE status='PAID' AND date(created_at)=date('now')`),
            ]);
            res.json({ success: true, data: {
                products: products.c, orders: orders.c, users: users.c,
                revenue: revenue.t, pendingOrders: pendingOrders.c,
                totalDeposit: totalDeposit.t, todayOrders: todayOrders.c, todayDeposit: todayDeposit.t,
            }});
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Products ──────────────────────────────────────
    async getProducts(req, res) {
        try {
            const products = await this.db.all(`SELECT p.*,c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.created_at DESC`);
            for (const p of products) { const cc = await this.db.getProductCodesCount(p.id); p.stock_available = cc.available; p.stock_total = cc.total; }
            res.json({ success: true, data: products });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async getProduct(req, res) {
        try {
            const p = await this.db.getProductById(req.params.id);
            if (!p) return res.status(404).json({ success: false, error: 'Product not found' });
            const cc = await this.db.getProductCodesCount(req.params.id);
            p.stock_available = cc.available; p.stock_total = cc.total;
            res.json({ success: true, data: p });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async createProduct(req, res) {
        try {
            const { name, description, price, category_id, product_type, download_link, product_code } = req.body;
            const file_path = req.file ? req.file.filename : null;
            await this.db.run(
                `INSERT INTO products (name,description,price,category_id,product_type,file_path,download_link,product_code,is_active,created_at) VALUES (?,?,?,?,?,?,?,?,1,datetime('now'))`,
                [name, description, parseFloat(price), category_id||null, product_type||'code', file_path, download_link||null, product_code||null]
            );
            res.json({ success: true, message: 'Product created' });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async updateProduct(req, res) {
        try {
            const { name, description, price, category_id, product_type, download_link, is_active } = req.body;
            await this.db.run(
                `UPDATE products SET name=?,description=?,price=?,category_id=?,product_type=?,download_link=?,is_active=? WHERE id=?`,
                [name, description, parseFloat(price), category_id||null, product_type, download_link||null, is_active?1:0, req.params.id]
            );
            res.json({ success: true, message: 'Product updated' });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async deleteProduct(req, res) {
        try { await this.db.run('DELETE FROM products WHERE id=?', [req.params.id]); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Product Codes / Stock ─────────────────────────
    async getProductCodes(req, res) {
        try {
            const codes = await this.db.getAllProductCodes(req.params.id);
            const count = await this.db.getProductCodesCount(req.params.id);
            res.json({ success: true, data: codes, stats: count });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    async addProductCodes(req, res) {
        try {
            const { codes } = req.body; // array of strings
            if (!codes || !codes.length) return res.status(400).json({ success: false, error: 'No codes provided' });
            const list = Array.isArray(codes) ? codes : [codes];
            const filtered = list.map(c => c.trim()).filter(Boolean);
            await this.db.addProductCodes(req.params.id, filtered);
            res.json({ success: true, message: `${filtered.length} kode berhasil ditambahkan` });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    async bulkAddCodes(req, res) {
        try {
            const { text, separator } = req.body;
            if (!text) return res.status(400).json({ success: false, error: 'No text provided' });
            const sep = separator || '\n';
            const codes = text.split(sep).map(c => c.trim()).filter(Boolean);
            if (!codes.length) return res.status(400).json({ success: false, error: 'No valid codes found' });
            await this.db.addProductCodes(req.params.id, codes);
            res.json({ success: true, message: `${codes.length} kode berhasil ditambahkan`, added: codes.length });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    async generateProductCodes(req, res) {
        try {
            const { count = 10, prefix = '' } = req.body;
            const codes = await this.db.generateProductCodes(req.params.id, parseInt(count), prefix);
            res.json({ success: true, message: `${codes.length} kode berhasil digenerate`, data: codes });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    async deleteUsedCodes(req, res) {
        try {
            const r = await this.db.run('DELETE FROM product_codes WHERE product_id=? AND is_used=1', [req.params.id]);
            res.json({ success: true, message: `${r.changes} kode terpakai dihapus` });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    async deleteProductCode(req, res) {
        try { await this.db.deleteProductCode(req.params.codeId); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Categories ────────────────────────────────────
    async getCategories(req, res) {
        try { res.json({ success: true, data: await this.db.all('SELECT * FROM categories ORDER BY name') }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async createCategory(req, res) {
        try { await this.db.run('INSERT INTO categories (name,description,created_at) VALUES (?,?,datetime("now"))', [req.body.name, req.body.description||'']); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async updateCategory(req, res) {
        try { await this.db.run('UPDATE categories SET name=?,description=? WHERE id=?', [req.body.name, req.body.description||'', req.params.id]); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async deleteCategory(req, res) {
        try { await this.db.run('DELETE FROM categories WHERE id=?', [req.params.id]); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Orders ────────────────────────────────────────
    async getOrders(req, res) {
        try {
            const orders = await this.db.getAllOrders(100);
            res.json({ success: true, data: orders });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async getOrder(req, res) {
        try { const o = await this.db.get('SELECT o.*,u.username,u.first_name,p.name as product_name FROM orders o LEFT JOIN users u ON o.user_id=u.id LEFT JOIN products p ON o.product_id=p.id WHERE o.id=?', [req.params.id]); res.json({ success: true, data: o }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async updateOrderStatus(req, res) {
        try { await this.db.updateOrderStatus(req.params.id, req.body.status); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Users ─────────────────────────────────────────
    async getUsers(req, res) {
        try { res.json({ success: true, data: await this.db.all('SELECT id,telegram_id,username,first_name,last_name,COALESCE(balance,0) as balance,created_at,is_admin FROM users ORDER BY created_at DESC') }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async getUser(req, res) {
        try {
            const u = await this.db.get('SELECT * FROM users WHERE id=?', [req.params.id]);
            const txns = await this.db.getUserTransactions(req.params.id, 20);
            res.json({ success: true, data: { ...u, transactions: txns } });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async depositUserBalance(req, res) {
        try { await this.db.depositToBalance(req.params.id, parseFloat(req.body.amount), req.body.description||'Admin Deposit'); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async withdrawUserBalance(req, res) {
        try { await this.db.withdrawFromBalance(req.params.id, parseFloat(req.body.amount), req.body.description||'Admin Withdraw'); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Payments ──────────────────────────────────────
    async getAllPayments(req, res) {
        try {
            const pays = await this.db.all(`SELECT bp.*,u.username,u.first_name,u.telegram_id FROM balance_payments bp LEFT JOIN users u ON bp.user_id=u.id ORDER BY bp.created_at DESC LIMIT 200`);
            res.json({ success: true, data: pays });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async checkPaymentStatus(req, res) {
        try {
            const { checkTransactionStatus } = require('../services/atlanticService');
            const result = await checkTransactionStatus(req.params.reference);
            res.json({ success: true, data: result });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Transactions ──────────────────────────────────
    async getAllTransactions(req, res) {
        try { res.json({ success: true, data: await this.db.getAllTransactions(200) }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Redeem Codes ──────────────────────────────────
    async getAllRedeemCodes(req, res) {
        try { res.json({ success: true, data: await this.db.getAllRedeemCodes() }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async createRedeemCode(req, res) {
        try { const { code, amount } = req.body; await this.db.createRedeemCode(code, parseFloat(amount)); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async generateRedeemCode(req, res) {
        try { const { amount, prefix } = req.body; const code = await this.db.generateRedeemCode(parseFloat(amount), prefix||'RC'); res.json({ success: true, data: { code } }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async bulkGenerateRedeemCodes(req, res) {
        try {
            const { amount, count = 5, prefix = 'RC' } = req.body;
            const codes = [];
            for (let i = 0; i < parseInt(count); i++) {
                const code = await this.db.generateRedeemCode(parseFloat(amount), prefix);
                codes.push(code);
            }
            res.json({ success: true, data: codes });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async deleteRedeemCode(req, res) {
        try { await this.db.deleteRedeemCode(req.params.id); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Payment Channels ──────────────────────────────
    async getPaymentChannels(req, res) {
        try { res.json({ success: true, data: await getPaymentChannels() }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async getPaymentMethodConfig(req, res) {
        try { res.json({ success: true, data: await this.db.getPaymentMethodConfig() }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async updatePaymentMethodConfig(req, res) {
        try { await this.db.updatePaymentMethodConfig(req.body.default_method, []); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Atlantic Config ───────────────────────────────
    async getAtlanticConfig(req, res) {
        res.json({ success: true, data: {
            ATLANTIC_MERCHANT_ID: process.env.ATLANTIC_MERCHANT_ID || '',
            ATLANTIC_API_KEY: process.env.ATLANTIC_API_KEY ? '***set***' : '',
            ATLANTIC_BASE_URL: process.env.ATLANTIC_BASE_URL || 'https://atlantich2h.com/api/v1',
        }});
    }
    async updateAtlanticConfig(req, res) {
        try {
            const { ATLANTIC_MERCHANT_ID, ATLANTIC_SECRET_KEY, ATLANTIC_API_KEY, ATLANTIC_BASE_URL } = req.body;
            const envPath = path.join(__dirname, '../../.env');
            let content = '';
            try { content = fs.readFileSync(envPath, 'utf8'); } catch { try { content = fs.readFileSync(path.join(__dirname,'../../env.example'),'utf8'); } catch { content = ''; } }
            const updates = { ATLANTIC_MERCHANT_ID, ATLANTIC_SECRET_KEY, ATLANTIC_API_KEY, ATLANTIC_BASE_URL };
            for (const [k, v] of Object.entries(updates)) {
                if (!v) continue;
                const rx = new RegExp(`^${k}=.*`, 'm');
                if (rx.test(content)) content = content.replace(rx, `${k}=${v}`);
                else content += `\n${k}=${v}`;
            }
            fs.writeFileSync(envPath, content);
            require('dotenv').config();
            res.json({ success: true, message: 'Konfigurasi berhasil disimpan. Restart server agar perubahan berlaku.' });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Bot Config ────────────────────────────────────
    async getBotConfig(req, res) {
        try { res.json({ success: true, data: await this.db.getBotConfig() }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async updateBotConfig(req, res) {
        try { await this.db.updateBotConfig(req.body.welcome_message, req.body.help_message); res.json({ success: true }); }
        catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Broadcast ─────────────────────────────────────
    async sendBroadcast(req, res) {
        try {
            const { message, target = 'all' } = req.body;
            if (!message) return res.status(400).json({ success: false, error: 'Message is required' });
            if (!this.bot) return res.json({ success: false, error: 'Bot belum terhubung. Gunakan /broadcast di Telegram.' });
            let users;
            if (target === 'active') {
                users = await this.db.all('SELECT telegram_id FROM users WHERE is_admin=0 AND balance > 0');
            } else {
                users = await this.db.all('SELECT telegram_id FROM users WHERE is_admin=0');
            }
            let ok = 0, fail = 0;
            for (const u of users) {
                try {
                    await this.bot.sendMessage(u.telegram_id, message, { parse_mode: 'Markdown' });
                    ok++;
                    await new Promise(r => setTimeout(r, 50)); // rate limit
                } catch { fail++; }
            }
            res.json({ success: true, message: `Broadcast selesai! ✅ Berhasil: ${ok}, Gagal: ${fail}, Total: ${users.length}` });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Analytics ─────────────────────────────────────
    async getAnalytics(req, res) {
        try {
            const days = parseInt(req.query.days) || 30;
            const [tp, to, tu, rev, pd, toPending, dailySales, dailyDeposits, topProducts] = await Promise.all([
                this.db.get('SELECT COUNT(*) as c FROM products WHERE is_active=1'),
                this.db.get(`SELECT COUNT(*) as c FROM orders WHERE status='completed'`),
                this.db.get('SELECT COUNT(*) as c FROM users WHERE is_admin=0'),
                this.db.get(`SELECT COALESCE(SUM(total_price),0) as t FROM orders WHERE status='completed'`),
                this.db.get(`SELECT COALESCE(SUM(amount),0) as t FROM balance_payments WHERE status='PAID'`),
                this.db.get(`SELECT COUNT(*) as c FROM orders WHERE status='pending'`),
                this.db.all(`SELECT date(created_at) as date, COUNT(*) as orders, COALESCE(SUM(total_price),0) as revenue
                    FROM orders WHERE status='completed' AND created_at >= date('now','-${days} days')
                    GROUP BY date(created_at) ORDER BY date`),
                this.db.all(`SELECT date(created_at) as date, COUNT(*) as count, COALESCE(SUM(amount),0) as total
                    FROM balance_payments WHERE status='PAID' AND created_at >= date('now','-${days} days')
                    GROUP BY date(created_at) ORDER BY date`),
                this.db.all(`SELECT p.name, COUNT(o.id) as sales, COALESCE(SUM(o.total_price),0) as revenue
                    FROM orders o JOIN products p ON o.product_id=p.id WHERE o.status='completed'
                    GROUP BY o.product_id ORDER BY sales DESC LIMIT 10`),
            ]);
            res.json({ success: true, data: {
                totalProducts: tp.c, totalOrders: to.c, totalUsers: tu.c,
                totalRevenue: rev.t, totalDeposits: pd.t, pendingOrders: toPending.c,
                dailySales, dailyDeposits, topProducts,
            }});
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }

    // ── Files ─────────────────────────────────────────
    async getFiles(req, res) {
        try {
            const uploadPath = process.env.UPLOAD_PATH || './uploads';
            const files = await fs.readdir(uploadPath);
            res.json({ success: true, data: files });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
    async deleteFile(req, res) {
        try {
            const filePath = path.join(process.env.UPLOAD_PATH || './uploads', req.params.filename);
            await fs.remove(filePath);
            res.json({ success: true });
        } catch (e) { res.status(500).json({ success: false, error: e.message }); }
    }
}

module.exports = AdminAPI;
