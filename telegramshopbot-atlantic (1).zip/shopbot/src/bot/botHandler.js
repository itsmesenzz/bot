const PaymentService = require('../services/paymentService');

class BotHandler {
    constructor(bot, db) {
        this.bot = bot;
        this.db = db;
        this.paymentService = new PaymentService(db);
        this.userStates = new Map();
        this.formatRupiah = (n) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(n);
        this.setupEventHandlers();
    }

    setupEventHandlers() {
        this.bot.onText(/\/start/, this.handleStart.bind(this));
        this.bot.onText(/\/help/, (msg) => this.handleHelp(msg.chat.id));
        this.bot.onText(/\/shop/, (msg) => this.showProducts(msg.chat.id));
        this.bot.onText(/\/cart/, (msg) => this.showCart(msg.chat.id));
        this.bot.onText(/\/balance/, this.handleBalance.bind(this));
        this.bot.onText(/\/deposit/, (msg) => this.handleDeposit(msg.chat.id));
        this.bot.onText(/\/orders/, (msg) => this.showOrders(msg.chat.id));
        this.bot.onText(/\/admin/, this.handleAdmin.bind(this));
        this.bot.onText(/\/redeem/, (msg) => { this.userStates.set(msg.chat.id, { state: 'redeem' }); this.bot.sendMessage(msg.chat.id, '🎟️ Masukkan kode voucher Anda:'); });
        this.bot.onText(/\/status (.+)/, async (msg, m) => this.checkPaymentStatus(msg.chat.id, m[1].trim()));
        this.bot.onText(/\/broadcast/, this.handleBroadcast.bind(this));
        this.bot.onText(/\/stats/, this.handleStats.bind(this));
        this.bot.on('callback_query', this.handleCallback.bind(this));
        this.bot.on('message', this.handleMessage.bind(this));
    }

    /* ── START ── */
    async handleStart(msg) {
        const chatId = msg.chat.id;
        const u = msg.from;
        await this.db.createUser(u.id, u.username, u.first_name, u.last_name);
        let wm;
        try { const c = await this.db.getBotConfig(); wm = c?.welcome_message?.replace(/{first_name}/g, u.first_name || 'User'); } catch {}
        wm = wm || `🛍️ *Selamat datang, ${u.first_name || 'User'}!*\n\nToko Digital – belanja mudah & aman.\n\n/shop • /cart • /balance • /deposit • /orders • /redeem • /help`;
        await this.bot.sendMessage(chatId, wm, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [
            [{ text: '🛍️ Produk', callback_data: 'shop' }, { text: '🛒 Keranjang', callback_data: 'cart' }],
            [{ text: '💰 Saldo', callback_data: 'balance' }, { text: '💳 Top Up', callback_data: 'deposit' }],
            [{ text: '📋 Pesanan', callback_data: 'orders' }, { text: '❓ Bantuan', callback_data: 'help' }],
        ]}});
    }

    async handleHelp(chatId) {
        await this.bot.sendMessage(chatId,
            `❓ *Bantuan*\n\n/shop – Lihat produk\n/cart – Keranjang\n/balance – Saldo\n/deposit – Top up saldo\n/orders – Pesanan saya\n/redeem – Tukar voucher\n/status REF – Cek status bayar\n\n💡 Setelah top up, klik tombol *Cek Status Pembayaran* untuk memperbarui saldo.`,
            { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'start' }]] }}
        );
    }

    async handleBalance(msg) {
        const chatId = msg.chat.id;
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user) return this.bot.sendMessage(chatId, '❌ Gunakan /start terlebih dahulu.');
        const { message, keyboard } = await this.balanceMsg(user.id);
        await this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown', reply_markup: keyboard });
    }

    async balanceMsg(userId) {
        const bal = await this.db.getUserBalance(userId);
        const txns = await this.db.getUserTransactions(userId, 5);
        let msg = `💰 *Saldo Anda*\n\n💳 *Saldo:* ${this.formatRupiah(bal)}\n`;
        if (txns.length) { msg += '\n📋 *Transaksi Terakhir:*\n'; for (const t of txns) msg += `${t.type==='deposit'?'➕':'➖'} ${this.formatRupiah(Math.abs(t.amount))} – ${(t.description||'').slice(0,30)}\n`; }
        return { message: msg, keyboard: { inline_keyboard: [
            [{ text: '💳 Top Up', callback_data: 'deposit' }, { text: '📋 Transaksi', callback_data: 'transactions' }],
            [{ text: '🛍️ Belanja', callback_data: 'shop' }, { text: '🏠 Menu', callback_data: 'start' }]
        ]}};
    }

    /* ── PRODUCTS ── */
    async showProducts(chatId, catId = null, page = 1) {
        const ps = 6, offset = (page-1)*ps;
        const where = catId && catId !== 'all' ? `AND p.category_id=${parseInt(catId)}` : '';
        const products = await this.db.all(`SELECT p.*,c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.is_active=1 ${where} ORDER BY p.created_at DESC LIMIT ? OFFSET ?`, [ps, offset]);
        const { c: total } = await this.db.get(`SELECT COUNT(*) as c FROM products p WHERE p.is_active=1 ${where}`);
        const totalPages = Math.ceil(total / ps) || 1;

        if (!products.length) return this.bot.sendMessage(chatId, '📭 Tidak ada produk tersedia.', { reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'start' }]] }});

        let msg = `🛍️ *Produk Tersedia* (Hal ${page}/${totalPages})\n\n`;
        const rows = [];
        for (const p of products) {
            const cc = await this.db.getProductCodesCount(p.id);
            const stk = cc.available > 0 ? `✅ ${cc.available}` : '❌ Habis';
            msg += `*${p.name}*  💰 ${this.formatRupiah(p.price)}  📦 ${stk}\n`;
            if (p.description) msg += `_${p.description.slice(0,50)}${p.description.length>50?'...':''}_\n`;
            msg += '\n';
            rows.push([{ text: `👁 ${p.name}`, callback_data: `product_${p.id}` }, { text: '🛒 Beli', callback_data: `addcart_${p.id}` }]);
        }

        const nav = [];
        if (page > 1) nav.push({ text: '◀️', callback_data: `cat_${catId||'all'}_${page-1}` });
        nav.push({ text: `${page}/${totalPages}`, callback_data: 'noop' });
        if (page < totalPages) nav.push({ text: '▶️', callback_data: `cat_${catId||'all'}_${page+1}` });
        rows.push(nav);
        rows.push([{ text: '🛒 Keranjang', callback_data: 'cart' }, { text: '🏠 Menu', callback_data: 'start' }]);

        await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: rows }});
    }

    async showProductDetail(chatId, productId) {
        const p = await this.db.getProductById(productId);
        if (!p) return this.bot.sendMessage(chatId, '❌ Produk tidak ditemukan.');
        const cc = await this.db.getProductCodesCount(productId);
        const msg = `*${p.name}*\n\n📝 ${p.description||'Tidak ada deskripsi'}\n\n💰 *Harga:* ${this.formatRupiah(p.price)}\n📦 *Stok:* ${cc.available > 0 ? `✅ ${cc.available} tersedia` : '❌ Habis Stok'}\n🏷️ *Kategori:* ${p.category_name||'Umum'}\n📋 *Jenis:* ${p.product_type}`;
        const canBuy = cc.available > 0;
        await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [
            canBuy ? [{ text: '🛒 Tambah ke Keranjang', callback_data: `addcart_${productId}` }] : [{ text: '❌ Habis Stok', callback_data: 'shop' }],
            [{ text: '◀️ Kembali', callback_data: 'shop' }]
        ]}});
    }

    async addToCart(chatId, productId) {
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user) return this.bot.sendMessage(chatId, '❌ Gunakan /start terlebih dahulu.');
        const p = await this.db.getProductById(productId);
        if (!p) return this.bot.sendMessage(chatId, '❌ Produk tidak ditemukan.');
        const cc = await this.db.getProductCodesCount(productId);
        if (!cc.available) return this.bot.sendMessage(chatId, '❌ Produk habis stok.');
        const ex = await this.db.get('SELECT quantity FROM cart WHERE user_id=? AND product_id=?', [user.id, productId]);
        if ((ex?.quantity||0)+1 > cc.available) return this.bot.sendMessage(chatId, `❌ Hanya ${cc.available} unit tersedia.`);
        await this.db.addToCart(user.id, productId, 1);
        await this.bot.sendMessage(chatId, `✅ *${p.name}* ditambahkan ke keranjang!`, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🛒 Keranjang', callback_data: 'cart' }, { text: '🛍️ Lanjut', callback_data: 'shop' }]] }});
    }

    async showCart(chatId) {
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user) return this.bot.sendMessage(chatId, '❌ Gunakan /start terlebih dahulu.');
        const items = await this.db.getCart(user.id);
        if (!items.length) return this.bot.sendMessage(chatId, '🛒 Keranjang kosong.', { reply_markup: { inline_keyboard: [[{ text: '🛍️ Belanja', callback_data: 'shop' }]] }});
        let total = 0, msg = '🛒 *Keranjang Belanja*\n\n';
        for (const i of items) { const sub = parseFloat(i.price)*i.quantity; total += sub; msg += `• *${i.name}* ×${i.quantity} = ${this.formatRupiah(sub)}\n`; }
        const bal = await this.db.getUserBalance(user.id);
        msg += `\n💰 *Total:* ${this.formatRupiah(total)}\n💳 *Saldo:* ${this.formatRupiah(bal)}`;
        if (bal < total) msg += `\n⚠️ Kurang: ${this.formatRupiah(total-bal)}`;
        const kb = [[{ text: '✅ Checkout', callback_data: 'checkout' }, { text: '🗑️ Kosongkan', callback_data: 'clearcart' }]];
        if (bal < total) kb.unshift([{ text: '💳 Top Up Saldo', callback_data: 'deposit' }]);
        kb.push([{ text: '🛍️ Lanjut', callback_data: 'shop' }, { text: '🏠 Menu', callback_data: 'start' }]);
        await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: kb }});
    }

    async checkout(chatId) {
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user) return this.bot.sendMessage(chatId, '❌ Gunakan /start terlebih dahulu.');
        const items = await this.db.getCart(user.id);
        if (!items.length) return this.bot.sendMessage(chatId, '🛒 Keranjang kosong!');
        for (const i of items) { const cc = await this.db.getProductCodesCount(i.product_id); if (cc.available < i.quantity) return this.bot.sendMessage(chatId, `❌ Stok tidak cukup: ${i.name} (tersedia: ${cc.available})`); }
        const total = items.reduce((s, i) => s + parseFloat(i.price)*i.quantity, 0);
        const bal = await this.db.getUserBalance(user.id);
        if (bal < total) return this.bot.sendMessage(chatId, `❌ Saldo kurang ${this.formatRupiah(total-bal)}`, { reply_markup: { inline_keyboard: [[{ text: '💳 Top Up', callback_data: 'deposit' }]] }});
        await this.db.withdrawFromBalance(user.id, total, `Pembelian: ${items.map(i=>i.name).join(', ')}`);
        for (const i of items) {
            const codes = await this.db.getAvailableProductCodes(i.product_id, i.quantity);
            const o = await this.db.createOrder(user.id, i.product_id, i.quantity, parseFloat(i.price)*i.quantity);
            for (const c of codes) await this.db.useProductCode(c.id, user.id);
            await this.db.updateOrderStatus(o.id, 'completed');
        }
        await this.db.clearCart(user.id);
        await this.deliverProducts(chatId, items);
        await this.bot.sendMessage(chatId, '✅ Pembayaran berhasil! Produk telah dikirim.');
    }

    async deliverProducts(chatId, items) {
        const user = await this.db.getUserByTelegramId(chatId);
        for (const i of items) {
            const p = await this.db.getProductById(i.product_id);
            if (!p) continue;
            let msg = `📦 *Produk Dikirim: ${p.name}*\n\n`;
            if (p.product_type === 'file' && p.file_path) msg += `📁 *Link:*\n${process.env.BASE_URL||'http://localhost:3000'}/uploads/${p.file_path}\n\n`;
            else if (p.product_type === 'link' && p.download_link) msg += `🔗 *Link:*\n${p.download_link}\n\n`;
            else if (p.product_type === 'code') {
                const used = await this.db.all('SELECT code FROM product_codes WHERE product_id=? AND used_by_user_id=? AND is_used=1 ORDER BY used_at DESC LIMIT ?', [p.id, user.id, i.quantity]);
                if (used.length) msg += `🔑 *Kode:*\n\`${used.map(c=>c.code).join('\n')}\`\n\n`;
            }
            msg += `💡 Cek pesanan: /orders`;
            await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown' });
        }
    }

    async showOrders(chatId) {
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user) return this.bot.sendMessage(chatId, '❌ Gunakan /start terlebih dahulu.');
        const orders = await this.db.getUserOrders(user.id, 10);
        if (!orders.length) return this.bot.sendMessage(chatId, '📋 Belum ada pesanan.', { reply_markup: { inline_keyboard: [[{ text: '🛍️ Belanja', callback_data: 'shop' }]] }});
        let msg = '📋 *Riwayat Pesanan*\n\n';
        for (const o of orders) {
            const e = { completed: '✅', pending: '⏳', cancelled: '❌' }[o.status] || '❓';
            msg += `${e} *#${o.id}* – ${o.product_name}\n   💰 ${this.formatRupiah(o.total_price)} | ${new Date(o.created_at).toLocaleDateString('id-ID')}\n\n`;
        }
        await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🛍️ Belanja', callback_data: 'shop' }, { text: '🏠 Menu', callback_data: 'start' }]] }});
    }

    /* ── DEPOSIT / PAYMENT ── */
    async handleDeposit(chatId) {
        const amounts = [10000, 25000, 50000, 100000, 250000, 500000];
        const rows = [];
        for (let i = 0; i < amounts.length; i += 2) rows.push(amounts.slice(i,i+2).map(a => ({ text: this.formatRupiah(a), callback_data: `depamt_${a}` })));
        rows.push([{ text: '💬 Jumlah Lainnya', callback_data: 'dep_custom' }]);
        rows.push([{ text: '📋 Riwayat', callback_data: 'payment_history' }, { text: '🏠 Menu', callback_data: 'start' }]);
        await this.bot.sendMessage(chatId, `💳 *Top Up Saldo*\n\nPilih nominal:`, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: rows }});
    }

    async showMethodSelect(chatId, amount) {
        const channels = await this.paymentService.getChannels();
        const rows = channels.map(c => [{ text: `${c.icon} ${c.name}`, callback_data: `paym_${c.code}_${amount}` }]);
        rows.push([{ text: '◀️ Kembali', callback_data: 'deposit' }]);
        await this.bot.sendMessage(chatId, `💳 *Pilih Metode Bayar*\n\n💰 Nominal: *${this.formatRupiah(amount)}*`, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: rows }});
    }

    async processDeposit(chatId, amount, method) {
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user) return this.bot.sendMessage(chatId, '❌ Gunakan /start terlebih dahulu.');
        const wm = await this.bot.sendMessage(chatId, '⏳ Membuat tagihan...');
        try {
            const r = await this.paymentService.createBalancePayment(user.id, amount, user.first_name||user.username||'User', null, null, method);
            const { reference, paymentUrl, qrUrl, qrString, vaNumber, bankName, paymentMethod } = r.data;
            let msg = `✅ *Tagihan Dibuat!*\n\n💰 *Nominal:* ${this.formatRupiah(amount)}\n💳 *Metode:* ${paymentMethod}\n🔢 *Referensi:* \`${reference}\`\n`;
            if (vaNumber) msg += `🏦 *No. VA ${bankName||''}:* \`${vaNumber}\`\n`;
            if (qrString) msg += `\n📱 QR String tersedia\n`;
            msg += `\n⏰ Berlaku 1 jam\n\n💡 Setelah bayar, klik *Cek Status* di bawah.`;
            const btns = [];
            if (paymentUrl) btns.push([{ text: '🌐 Bayar Sekarang', url: paymentUrl }]);
            if (qrUrl) btns.push([{ text: '📱 QR Code', url: qrUrl }]);
            btns.push([{ text: '🔄 Cek Status Pembayaran', callback_data: `chkpay_${reference}` }]);
            btns.push([{ text: '📋 Riwayat', callback_data: 'payment_history' }, { text: '🏠 Menu', callback_data: 'start' }]);
            await this.bot.editMessageText(msg, { chat_id: chatId, message_id: wm.message_id, parse_mode: 'Markdown', reply_markup: { inline_keyboard: btns }});
            if (qrUrl) { try { await this.bot.sendPhoto(chatId, qrUrl, { caption: `📱 QR untuk ${this.formatRupiah(amount)}\nRef: \`${reference}\``, parse_mode: 'Markdown' }); } catch {} }
        } catch (err) {
            await this.bot.editMessageText(`❌ Gagal: ${err.message}\n\nSilakan coba lagi atau hubungi admin.`, { chat_id: chatId, message_id: wm.message_id });
        }
    }

    async checkPaymentStatus(chatId, reference) {
        const wm = await this.bot.sendMessage(chatId, '🔄 Memeriksa...');
        try {
            await this.paymentService.checkPaymentStatus(reference);
            const pay = await this.db.get('SELECT * FROM balance_payments WHERE tripay_reference=?', [reference]);
            if (!pay) return this.bot.editMessageText('❌ Data tidak ditemukan.', { chat_id: chatId, message_id: wm.message_id });
            const icons = { PAID:'✅', PENDING:'⏳', EXPIRED:'⏰', FAILED:'❌' };
            const labels = { PAID:'Lunas', PENDING:'Menunggu', EXPIRED:'Kedaluwarsa', FAILED:'Gagal' };
            let msg = `${icons[pay.status]||'❓'} *Status Pembayaran*\n\n💰 *Nominal:* ${this.formatRupiah(pay.amount)}\n🔢 *Ref:* \`${reference}\`\n📊 *Status:* ${labels[pay.status]||pay.status}\n`;
            if (pay.status === 'PAID') { const u = await this.db.getUserByTelegramId(chatId); const nb = u ? await this.db.getUserBalance(u.id) : 0; msg += `\n🎉 Saldo diperbarui!\n💳 *Saldo Baru:* ${this.formatRupiah(nb)}`; }
            else if (pay.status === 'PENDING') msg += `\n💡 Selesaikan pembayaran Anda.`;
            const btns = [];
            if (pay.status === 'PENDING') btns.push([{ text: '🔄 Cek Lagi', callback_data: `chkpay_${reference}` }]);
            btns.push([{ text: '💳 Top Up Lagi', callback_data: 'deposit' }, { text: '🛍️ Belanja', callback_data: 'shop' }]);
            btns.push([{ text: '🏠 Menu', callback_data: 'start' }]);
            await this.bot.editMessageText(msg, { chat_id: chatId, message_id: wm.message_id, parse_mode: 'Markdown', reply_markup: { inline_keyboard: btns }});
        } catch (err) {
            await this.bot.editMessageText(`❌ Error: ${err.message}`, { chat_id: chatId, message_id: wm.message_id });
        }
    }

    async showPaymentHistory(chatId) {
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user) return;
        const pays = await this.paymentService.getUserPaymentHistory(user.id, 10);
        if (!pays.length) return this.bot.sendMessage(chatId, '📋 Belum ada riwayat pembayaran.');
        let msg = '📋 *Riwayat Pembayaran*\n\n';
        for (const p of pays) { const i = p.status==='PAID'?'✅':p.status==='PENDING'?'⏳':'❌'; msg += `${i} ${this.formatRupiah(p.amount)} – ${p.status}\n   \`${p.tripay_reference||'N/A'}\`\n   ${new Date(p.created_at).toLocaleDateString('id-ID')}\n\n`; }
        await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '💳 Top Up', callback_data: 'deposit' }, { text: '🏠 Menu', callback_data: 'start' }]] }});
    }

    async showTransactions(chatId) {
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user) return;
        const txns = await this.db.getUserTransactions(user.id, 20);
        if (!txns.length) return this.bot.sendMessage(chatId, '📋 Tidak ada transaksi.');
        let msg = '📋 *Riwayat Transaksi*\n\n';
        for (const t of txns) msg += `${t.type==='deposit'?'➕':'➖'} ${this.formatRupiah(Math.abs(t.amount))} – ${(t.description||'').slice(0,35)}\n   ${new Date(t.created_at).toLocaleDateString('id-ID')}\n\n`;
        await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '💰 Saldo', callback_data: 'balance' }, { text: '🏠 Menu', callback_data: 'start' }]] }});
    }

    /* ── ADMIN ── */
    async handleAdmin(msg) {
        const chatId = msg.chat.id;
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user?.is_admin) return this.bot.sendMessage(chatId, '❌ Akses ditolak.');
        await this.bot.sendMessage(chatId, `🔧 *Panel Admin*`, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [
            [{ text: '📦 Produk', callback_data: 'adm_products' }, { text: '➕ Tambah Produk', callback_data: 'adm_addproduct' }],
            [{ text: '📋 Pesanan', callback_data: 'adm_orders' }, { text: '📊 Statistik', callback_data: 'adm_stats' }],
            [{ text: '👥 Pengguna', callback_data: 'adm_users' }, { text: '💰 Transaksi', callback_data: 'adm_transactions' }],
            [{ text: '📢 Broadcast', callback_data: 'adm_broadcast' }, { text: '💳 Deposit', callback_data: 'adm_deposits' }],
            [{ text: '🎟️ Voucher', callback_data: 'adm_redeem' }, { text: '🏠 Menu', callback_data: 'start' }],
        ]}});
    }

    async handleStats(msg) {
        const chatId = msg.chat.id;
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user?.is_admin) return this.bot.sendMessage(chatId, '❌ Akses ditolak.');
        await this.showAdminStats(chatId);
    }

    async showAdminStats(chatId) {
        const [tp, to, tu, rev, pd] = await Promise.all([
            this.db.get('SELECT COUNT(*) as c FROM products WHERE is_active=1'),
            this.db.get('SELECT COUNT(*) as c FROM orders'),
            this.db.get('SELECT COUNT(*) as c FROM users WHERE is_admin=0'),
            this.db.get(`SELECT COALESCE(SUM(total_price),0) as t FROM orders WHERE status='completed'`),
            this.db.get(`SELECT COALESCE(SUM(amount),0) as t FROM balance_payments WHERE status='PAID'`),
        ]);
        const today = new Date().toISOString().slice(0,10);
        const [to2, td2] = await Promise.all([
            this.db.get(`SELECT COUNT(*) as c FROM orders WHERE date(created_at)=?`,[today]),
            this.db.get(`SELECT COALESCE(SUM(amount),0) as t FROM balance_payments WHERE status='PAID' AND date(created_at)=?`,[today]),
        ]);
        await this.bot.sendMessage(chatId,
            `📊 *Statistik*\n\n📦 Produk aktif: *${tp.c}*\n📋 Total pesanan: *${to.c}*\n👥 Pengguna: *${tu.c}*\n💰 Penjualan: *${this.formatRupiah(rev.t)}*\n💳 Total deposit: *${this.formatRupiah(pd.t)}*\n\n📅 *Hari Ini:*\n   📋 Pesanan: *${to2.c}*\n   💳 Deposit: *${this.formatRupiah(td2.t)}*`,
            { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🔄 Refresh', callback_data: 'adm_stats' }, { text: '🔧 Admin', callback_data: 'adm_menu' }]] }});
    }

    async handleBroadcast(msg) {
        const chatId = msg.chat.id;
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user?.is_admin) return this.bot.sendMessage(chatId, '❌ Akses ditolak.');
        await this.startBroadcastFlow(chatId);
    }

    async startBroadcastFlow(chatId) {
        this.userStates.set(chatId, { state: 'broadcast' });
        await this.bot.sendMessage(chatId, `📢 *Broadcast*\n\nTulis pesan yang akan dikirim ke semua pengguna.\nSupport Markdown. Ketik /cancel untuk batal.`, { parse_mode: 'Markdown' });
    }

    async executeBroadcast(chatId, text) {
        const users = await this.db.all('SELECT telegram_id FROM users WHERE is_admin=0');
        let ok = 0, fail = 0;
        const sm = await this.bot.sendMessage(chatId, `📢 Mengirim ke ${users.length} pengguna...`);
        for (const u of users) {
            try { await this.bot.sendMessage(u.telegram_id, text, { parse_mode: 'Markdown' }); ok++; await new Promise(r=>setTimeout(r,50)); }
            catch { fail++; }
        }
        await this.bot.editMessageText(`✅ *Broadcast Selesai!*\n\n✅ Berhasil: ${ok}\n❌ Gagal: ${fail}\n📊 Total: ${users.length}`, { chat_id: chatId, message_id: sm.message_id, parse_mode: 'Markdown' });
    }

    async handleAdminCallback(chatId, data) {
        const user = await this.db.getUserByTelegramId(chatId);
        if (!user?.is_admin) return this.bot.sendMessage(chatId, '❌ Akses ditolak.');

        if (data === 'adm_products' || data === 'admin_products') {
            const prods = await this.db.all(`SELECT p.*,c.name as cat FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.created_at DESC LIMIT 20`);
            if (!prods.length) return this.bot.sendMessage(chatId, '📦 Belum ada produk.');
            let msg = '📦 *Daftar Produk*\n\n';
            for (const p of prods) {
                const cc = await this.db.getProductCodesCount(p.id);
                msg += `${p.is_active?'✅':'❌'} *${p.name}*\n   💰 ${this.formatRupiah(p.price)} | 📦 Stok: ${cc.available}/${cc.total}\n\n`;
            }
            await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '➕ Tambah', callback_data: 'adm_addproduct' }, { text: '🔧 Admin', callback_data: 'adm_menu' }]] }});

        } else if (data === 'adm_addproduct' || data === 'admin_add_product') {
            this.userStates.set(chatId, { state: 'add_product', step: 'name', data: {} });
            await this.bot.sendMessage(chatId, `➕ *Tambah Produk*\n\nLangkah 1: Kirim *nama produk*:`, { parse_mode: 'Markdown' });

        } else if (data === 'adm_orders' || data === 'admin_orders') {
            const orders = await this.db.getAllOrders(15);
            if (!orders.length) return this.bot.sendMessage(chatId, '📋 Belum ada pesanan.');
            let msg = '📋 *Pesanan Terbaru*\n\n';
            for (const o of orders) { const e = { completed:'✅', pending:'⏳', cancelled:'❌' }[o.status]||'❓'; msg += `${e} *#${o.id}* – ${o.product_name}\n   👤 ${o.first_name||o.username} | 💰 ${this.formatRupiah(o.total_price)}\n   📅 ${new Date(o.created_at).toLocaleDateString('id-ID')}\n\n`; }
            await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🔧 Admin', callback_data: 'adm_menu' }]] }});

        } else if (data === 'adm_stats' || data === 'admin_stats' || data === 'admin_analytics') {
            await this.showAdminStats(chatId);

        } else if (data === 'adm_users' || data === 'admin_users') {
            const users = await this.db.all('SELECT * FROM users WHERE is_admin=0 ORDER BY created_at DESC LIMIT 15');
            let msg = '👥 *Pengguna*\n\n';
            for (const u of users) msg += `👤 *${u.first_name||'N/A'}* (@${u.username||'N/A'})\n   💰 ${this.formatRupiah(u.balance||0)} | ID: ${u.telegram_id}\n\n`;
            await this.bot.sendMessage(chatId, msg||'Belum ada pengguna.', { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🔧 Admin', callback_data: 'adm_menu' }]] }});

        } else if (data === 'adm_transactions' || data === 'admin_transactions') {
            const txns = await this.db.getAllTransactions(15);
            let msg = '📋 *Transaksi*\n\n';
            for (const t of txns) msg += `${t.type==='deposit'?'➕':'➖'} ${this.formatRupiah(Math.abs(t.amount))} – ${t.first_name||t.username||'N/A'}\n   _${(t.description||'').slice(0,35)}_\n\n`;
            await this.bot.sendMessage(chatId, msg||'Belum ada transaksi.', { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🔧 Admin', callback_data: 'adm_menu' }]] }});

        } else if (data === 'adm_deposits' || data === 'admin_deposits') {
            const deps = await this.paymentService.getAllPayments(15);
            let msg = '💳 *Deposit Masuk*\n\n';
            for (const d of deps) { const i = d.status==='PAID'?'✅':d.status==='PENDING'?'⏳':'❌'; msg += `${i} ${this.formatRupiah(d.amount)} – ${d.first_name||d.username||'N/A'}\n   \`${d.tripay_reference}\`\n   ${new Date(d.created_at).toLocaleDateString('id-ID')}\n\n`; }
            await this.bot.sendMessage(chatId, msg||'Belum ada deposit.', { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🔧 Admin', callback_data: 'adm_menu' }]] }});

        } else if (data === 'adm_broadcast' || data === 'admin_broadcast') {
            await this.startBroadcastFlow(chatId);

        } else if (data === 'adm_redeem' || data === 'admin_redeem') {
            const codes = await this.db.getAllRedeemCodes();
            let msg = '🎟️ *Kode Voucher*\n\n';
            for (const c of (codes||[]).slice(0,15)) msg += `${c.is_used?'✅':'🟢'} \`${c.code}\` – ${this.formatRupiah(c.amount)}\n`;
            if (!codes?.length) msg += 'Belum ada kode.';
            await this.bot.sendMessage(chatId, msg, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [
                [{ text: '➕ Buat Kode', callback_data: 'adm_createredeem' }],
                [{ text: '🔧 Admin', callback_data: 'adm_menu' }]
            ]}});

        } else if (data === 'adm_createredeem') {
            this.userStates.set(chatId, { state: 'create_redeem' });
            await this.bot.sendMessage(chatId, '🎟️ Masukkan nominal kode voucher (contoh: 50000):');

        } else if (data === 'adm_menu' || data === 'admin_menu') {
            await this.handleAdmin({ chat: { id: chatId }, from: { id: chatId } });
        }
    }

    /* ── CALLBACK ROUTER ── */
    async handleCallback(cbq) {
        const chatId = cbq.message.chat.id;
        const data = cbq.data;
        try {
            await this.bot.answerCallbackQuery(cbq.id);
            if (data === 'start') return this.handleStart({ chat: { id: chatId }, from: cbq.from });
            if (data === 'help') return this.handleHelp(chatId);
            if (data === 'shop') return this.showProducts(chatId);
            if (data === 'cart') return this.showCart(chatId);
            if (data === 'orders') return this.showOrders(chatId);
            if (data === 'balance' || data === 'my_balance') { const u = await this.db.getUserByTelegramId(chatId); if (!u) return; const { message, keyboard } = await this.balanceMsg(u.id); return this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown', reply_markup: keyboard }); }
            if (data === 'deposit') return this.handleDeposit(chatId);
            if (data === 'transactions') return this.showTransactions(chatId);
            if (data === 'payment_history') return this.showPaymentHistory(chatId);
            if (data === 'checkout') return this.checkout(chatId);
            if (data === 'clearcart' || data === 'clear_cart') { const u = await this.db.getUserByTelegramId(chatId); if (u) await this.db.clearCart(u.id); return this.bot.sendMessage(chatId, '🗑️ Keranjang dikosongkan.', { reply_markup: { inline_keyboard: [[{ text: '🛍️ Belanja', callback_data: 'shop' }]] }}); }
            if (data === 'dep_custom' || data === 'deposit_custom') { this.userStates.set(chatId, { state: 'dep_amount' }); return this.bot.sendMessage(chatId, '💰 Masukkan nominal (min Rp10.000):'); }
            if (data === 'redeem_code') { this.userStates.set(chatId, { state: 'redeem' }); return this.bot.sendMessage(chatId, '🎟️ Masukkan kode voucher:'); }
            if (data === 'noop') return;
            if (data.startsWith('depamt_')) return this.showMethodSelect(chatId, parseFloat(data.slice(7)));
            if (data.startsWith('deposit_')) { const a = parseFloat(data.replace('deposit_','')); if (!isNaN(a)) return this.showMethodSelect(chatId, a); }
            if (data.startsWith('paym_')) { const parts = data.slice(5).split('_'); const amt = parseFloat(parts.pop()); const mth = parts.join('_'); return this.processDeposit(chatId, amt, mth); }
            if (data.startsWith('chkpay_') || data.startsWith('check_payment_')) return this.checkPaymentStatus(chatId, data.replace('chkpay_','').replace('check_payment_',''));
            if (data.startsWith('product_')) return this.showProductDetail(chatId, data.slice(8));
            if (data.startsWith('addcart_') || data.startsWith('add_to_cart_')) return this.addToCart(chatId, data.replace('addcart_','').replace('add_to_cart_',''));
            if (data.startsWith('cat_')) { const [,catId,page] = data.split('_'); return this.showProducts(chatId, catId==='all'?null:catId, parseInt(page)||1); }
            if (data.startsWith('category_')) { const parts = data.split('_'); const pg = parseInt(parts[parts.length-1])||1; const cat = parts.slice(1,-2).join('_'); return this.showProducts(chatId, cat==='all'?null:cat, pg); }
            if (data.startsWith('adm_') || data.startsWith('admin_')) return this.handleAdminCallback(chatId, data);
        } catch (err) {
            console.error('Callback error:', err);
            await this.bot.sendMessage(chatId, '❌ Terjadi kesalahan.');
        }
    }

    /* ── MESSAGE STATE MACHINE ── */
    async handleMessage(msg) {
        const chatId = msg.chat.id;
        const text = msg.text;
        if (!text || text.startsWith('/')) return;
        const state = this.userStates.get(chatId);
        if (!state) return;
        try {
            if (text === '/cancel') { this.userStates.delete(chatId); return this.bot.sendMessage(chatId, '❌ Dibatalkan.', { reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'start' }]] }}); }

            if (state.state === 'dep_amount' || state.state === 'awaiting_deposit_amount') {
                const amount = parseFloat(text.replace(/[^\d]/g,''));
                if (isNaN(amount)||amount<10000) return this.bot.sendMessage(chatId, '❌ Minimal Rp10.000:');
                this.userStates.delete(chatId);
                return this.showMethodSelect(chatId, amount);

            } else if (state.state === 'redeem' || state.state === 'awaiting_redeem_code') {
                const user = await this.db.getUserByTelegramId(chatId);
                if (!user) { this.userStates.delete(chatId); return; }
                try { const amt = await this.db.useRedeemCode(text.trim(), user.id); await this.bot.sendMessage(chatId, `✅ *${this.formatRupiah(parseFloat(amt))}* ditambahkan ke saldo!`, { parse_mode: 'Markdown' }); }
                catch (e) { await this.bot.sendMessage(chatId, `❌ Gagal: ${e.message}`); }
                this.userStates.delete(chatId);

            } else if (state.state === 'broadcast') {
                this.userStates.set(chatId, { state: 'broadcast_confirm', message: text });
                const { c } = await this.db.get('SELECT COUNT(*) as c FROM users WHERE is_admin=0');
                await this.bot.sendMessage(chatId, `📢 *Preview:*\n\n${text}\n\n---\nAkan dikirim ke *${c} pengguna*\nKonfirmasi?`, {
                    parse_mode: 'Markdown',
                    reply_markup: { inline_keyboard: [[{ text: '✅ Kirim', callback_data: 'bc_confirm' }, { text: '❌ Batal', callback_data: 'bc_cancel' }]] }
                });
                const self = this;
                const listener = async (cbq2) => {
                    if (cbq2.message.chat.id !== chatId) return;
                    await self.bot.answerCallbackQuery(cbq2.id);
                    const s2 = self.userStates.get(chatId);
                    if (cbq2.data === 'bc_confirm' && s2?.state === 'broadcast_confirm') {
                        self.userStates.delete(chatId);
                        await self.executeBroadcast(chatId, s2.message);
                    } else if (cbq2.data === 'bc_cancel') {
                        self.userStates.delete(chatId);
                        await self.bot.sendMessage(chatId, '❌ Broadcast dibatalkan.');
                    } else { return; }
                    self.bot.removeListener('callback_query', listener);
                };
                this.bot.on('callback_query', listener);

            } else if (state.state === 'create_redeem') {
                const amount = parseFloat(text.replace(/[^\d]/g,''));
                if (isNaN(amount)||amount<=0) return this.bot.sendMessage(chatId, '❌ Tidak valid. Masukkan angka:');
                const code = await this.db.generateRedeemCode(amount);
                this.userStates.delete(chatId);
                await this.bot.sendMessage(chatId, `✅ *Kode Dibuat!*\n\n🎟️ \`${code}\`\n💰 ${this.formatRupiah(amount)}`, { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '🎟️ Kelola Voucher', callback_data: 'adm_redeem' }]] }});

            } else if (state.state === 'add_product') {
                await this.addProductStep(chatId, text, state);
            }
        } catch (err) {
            console.error('Message error:', err);
            this.userStates.delete(chatId);
            await this.bot.sendMessage(chatId, '❌ Terjadi kesalahan.');
        }
    }

    async addProductStep(chatId, text, state) {
        if (state.step === 'name') {
            state.data.name = text; state.step = 'description';
            this.userStates.set(chatId, state);
            await this.bot.sendMessage(chatId, '📝 Langkah 2: Kirim *deskripsi produk*:', { parse_mode: 'Markdown' });

        } else if (state.step === 'description') {
            state.data.description = text; state.step = 'price';
            this.userStates.set(chatId, state);
            await this.bot.sendMessage(chatId, '💰 Langkah 3: Kirim *harga* (contoh: 25000):', { parse_mode: 'Markdown' });

        } else if (state.step === 'price') {
            const price = parseFloat(text.replace(/[^\d.]/g,''));
            if (isNaN(price)||price<=0) return this.bot.sendMessage(chatId, '❌ Harga tidak valid:');
            state.data.price = price; state.step = 'type';
            this.userStates.set(chatId, state);
            await this.bot.sendMessage(chatId, '📋 Langkah 4: Pilih *jenis produk*:', { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [
                [{ text: '🔑 Kode Digital', callback_data: 'ptype_code' }],
                [{ text: '🔗 Link Download', callback_data: 'ptype_link' }],
                [{ text: '📁 File Upload', callback_data: 'ptype_file' }],
            ]}});
            const self = this;
            const tl = async (cbq) => {
                if (cbq.message.chat.id !== chatId) return;
                await self.bot.answerCallbackQuery(cbq.id);
                if (!cbq.data.startsWith('ptype_')) return;
                self.bot.removeListener('callback_query', tl);
                const typeMap = { ptype_code:'code', ptype_link:'link', ptype_file:'file' };
                state.data.product_type = typeMap[cbq.data] || 'code';
                if (state.data.product_type === 'link') {
                    state.step = 'link'; self.userStates.set(chatId, state);
                    await self.bot.sendMessage(chatId, '🔗 Kirim *link download*:', { parse_mode: 'Markdown' });
                } else { await self.finalizeProduct(chatId, state.data); }
            };
            this.bot.on('callback_query', tl);

        } else if (state.step === 'link') {
            state.data.download_link = text;
            await this.finalizeProduct(chatId, state.data);
        }
    }

    async finalizeProduct(chatId, data) {
        try {
            const r = await this.db.run(
                `INSERT INTO products (name,description,price,product_type,download_link,is_active,created_at) VALUES (?,?,?,?,?,1,datetime('now'))`,
                [data.name, data.description, data.price, data.product_type||'code', data.download_link||null]
            );
            this.userStates.delete(chatId);
            const pid = r.id || r.lastID;
            await this.bot.sendMessage(chatId,
                `✅ *Produk Berhasil Ditambahkan!*\n\n📦 ${data.name}\n💰 ${this.formatRupiah(data.price)}\n📋 ${data.product_type||'code'}${data.product_type==='code'?'\n\n💡 Tambah stok kode melalui panel admin web.':''}`, {
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: [[{ text: '📦 Kelola Produk', callback_data: 'adm_products' }, { text: '🔧 Admin', callback_data: 'adm_menu' }]] }
            });
        } catch(err) {
            this.userStates.delete(chatId);
            await this.bot.sendMessage(chatId, `❌ Gagal: ${err.message}`);
        }
    }

    handleOrdersCommand() {}
}

module.exports = BotHandler;
